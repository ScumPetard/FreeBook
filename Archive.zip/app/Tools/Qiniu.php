<?php
namespace App\Tools;

/**
 * 七牛云工具类
 *
 * Class Qiniu
 * @package App\Tools
 */
class Qiniu
{

}