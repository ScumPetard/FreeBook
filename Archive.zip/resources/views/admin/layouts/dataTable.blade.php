<link rel="stylesheet" href="https://cdn.bootcss.com/datatables/1.10.15/css/dataTables.bootstrap.min.css">
<script src="https://cdn.bootcss.com/datatables/1.10.15/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.bootcss.com/datatables/1.10.15/js/dataTables.bootstrap.min.js"></script>